Extended Gang Wars 1.2
by Silent
Last update - 02.02.2020


DESCRIPTION

	San Andreas introduced gang wars to the series. According to beta game screenshots and the game code,
	Rockstar at some point planned to allow the player to have wars with all gangs in game. However,
	in retail game the player would only be able to take over Ballas' and Vagos' turfs. This modification
	unlocks gang wars with all gangs (even the unused ones, if any modification makes use of them)
	so the player can quite literally take over an entire state.


INSTALLATION

	As SA doesn't load ASI files by default, you need an ASI loader. In case you don't have one (if you
	use any ASI plugin such as CLEO, you can skip this step), you can download a decent loader here:
	http://www.gtagarage.com/mods/show.php?id=21709

	Rest of the installation is easy as pie. Just extract archive content to your SA directory
	and that's all. Make sure you check the INI!


SUPPORTED GAME VERSIONS

	* GTA SA 1.0 (all versions)
	* GTA SA 1.01 (all versions)
	* GTA SA 3.0 (Steam)


SUPPORTERS

	TWIST_OF_HATE


CONTACT

	zdanio95@gmail.com - e-mail
	Silent#1222 - Discord

Subscribe to my YouTube channel for more footage from my mods!
https://www.youtube.com/user/CookiePLMonster

Follow my Twitter account to be up to all my mods updates!
http://twitter.com/__silent_

Also take a look at my blog, featuring modding and programming related articles and more!
https://cookieplmonster.github.io/